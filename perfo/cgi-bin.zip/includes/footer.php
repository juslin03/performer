<div class="wrap-footer">
  <div class="row">
    <div class="small-12 large-6 columns"> Boulevard du Gabon, Abidjan Koumassi<br/>
      Tél. : +225 77 43 15 63 / +225 21 37 63 62<br/>
      <a href="mailto:info@performer.ci" title="Contactez-nous">Contactez-nous: info@performer.ci</a>
      <div class="row">
        <div class="small-12 medium-6 columns">
          <div class="controlle_etat_body"> <img src="images/armoirie.jpeg" alt="" /> Ministère de la Promotion des PME - MPPME</div>
        </div>
        <!--<div class="small-12 medium-6 columns">-->
        <!--  <div class="fede_footer_body"> <img src="images/logo_fdfp.jpg" alt="" /> Le Fonds de Développement de la Formation Professionnelle </div>-->
        <!--</div>-->
      </div>
    </div>
    <div class="small-12 medium-6 large-3 columns">
      <div class="social_title">Retrouvez-nous sur</div>
      <ul class="list-icon list-social">
        <li ><a href="#" target="_blank" class="social-sprite facebook" title="Suivez nous sur Facebook"></a></li>
        <li><a href="#" target="_blank" class="social-sprite twitter" title="Suivez nous sur Twitter"></a></li>
        <li><a href="#" target="_blank" class="social-sprite gplus" title="Suivez nous sur Google plus"></a></li>
        <li><a href="#" target="_blank" class="social-sprite viadeo" title="Suivez nous sur Viadéo"></a></li>
        <li><a href="#" target="_blank" class="social-sprite linkedin" title="Suivez nous sur Linkedin"></a></li>
        <li><a href="#" target="_blank" class="social-sprite pinterest" title="Suivez nous sur Pinterest"></a></li>
      </ul>
    </div>
    <div class="small-12 medium-6 large-3 columns show-for-large-up"> <a href="#" title="Demande de documentation" class="doc_footer" id="BoutonDocBottom"> </a> </div>
  </div>
</div>
<div class="wrap-legals">
  <div class="row">
    <div class="large-12 columns"> <a href="#" title="">&copy; copyright 2017, Performer</a> - <a href="#" title="Mentions légales">Mentions légales</a> </div>
  </div>
  <a class="exit-off-canvas"></a> </div>
