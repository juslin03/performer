<?php error_reporting(E_ALL); ?>
<!doctype html>
<html>

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <title>PERFORMER | Formation à distance </title>

  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1, user-scalable=no" />
  <link href='https://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
  <link href="favicon.ico" type="image/x-icon" rel="icon" />
  <link href="favicon.ico" type="image/x-icon" rel="shortcut icon" />
  <meta name="description" content="site de formation à distance" />
  <meta name="keywords" content="" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="css/style_performer.css" />
  <link rel="manifest" href="images/favicon.ico">
  <link rel="mask-icon" href="images/favicon.ico" color="#b55bd5">
  <meta name="msapplication-TileColor" content="#da532c">

</head>

<body>

  <div class="off-canvas-wrap" data-offcanvas>
    <div class="inner-wrap">
      <!-- HEADER -->
      <?php include 'includes/header.php'; ?>
      <!-- FIN HEADER -->

<!-- The Modal -->
<div id="myModal" class="modal">
  <!-- Modal content -->
  <div class="modal-content">
    <span class="close">&times;</span>
    <div class="home-banner"> <img src="images/entredigiteuz.jpeg" alt="Plus de 200 formations à distance" width="600" height="383">
      <div class="content panel tertiary">
        <div class="title upper">
          <div style="text-align:center;"> <a href="#">BOOTCAMP ENTRE DIGITEUZ</a> </div>
        </div>
        <div class="text primary">
          <div> Utiliser le digital comme levier pour booster votre business. </div>
        </div>
        <div class="form-actions a-center"> <a href="register.php" class="button btn">Inscrivez-vous maintenant !</a> </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
// Get the modal
var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
  modal.style.display = "none";
  modal.style.backgroundColor = 'rgba(032, 032, 032, 0.7)';
};

window.onload = function () {
  modal.style.display = "block";
}
// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};

</script>
      <!-- SLIDER -->
      <div class="slide_bg">
        <div class="wrapper_home">
          <div class="slide_content">
            <div id="home-slider">
              <div class="home-banner"> <img src="images/entredigiteuz.jpeg" alt="Plus de 200 formations à distance" width="600" height="383" />
                <div class="content panel tertiary">
                  <div class="title upper">
                    <div style="text-align:center;"> <a href="#">BOOTCAMP ENTRE DIGITEUZ</a> </div>
                  </div>
                  <div class="text primary">
                    <div> Inscrivez vous dès maintenant pour béneficier de cette formation. </div>
                  </div>
                  <div class="form-actions a-center"> <a href="register.php" class="button btn">S'inscrire</a> </div>
                </div>
              </div>
             
            </div>
            <div id="pager"></div>
          </div data-equalizer>

          <div class="bloc-search">
            <div class="search">
              <div class="search-item search-title"><span class="search-title_big">Candidatez</span> </div>
              <div class="search-item search-formation">
                <form action="" id="doc_express" novalidate method="get" accept-charset="utf-8">
                  <input name="query" placeholder="Votre Nom " class="radius field" id="query" type="text" />
                  <input name="query" placeholder="Votre Prènom " class="radius field" id="query" type="text" />
                  <input name="query" placeholder="Téléphone" class="radius field" id="query" type="text" />
                  <input name="query" placeholder="Email" class="radius field" id="query" type="text" />
              </div>

              <div class="search-item ">
                <button class="search-action" type="submit">Valider l'inscription</button>
                </form>
              </div>
            </div>
            
          </div>
        </div>
      </div>
      <!-- FIN SLIDER -->

      <!-- BOUTTONS VERT -->
      <div class="row collapse">
        <div class="large-12 columns">
          <ul class="small-block-grid-1 medium-block-grid-1 large-block-grid-3 block-type-formations mb-medium">

            <li> <a href="#" class="btn button full secondary type-formations">
                <img src="images/icones/icon-elearning.png" class="icon" alt="elearning" width="31" height="31" />
                <span class="upper text-icon ml-large"> <span class="text">Avec nous donnez vie à </span> <br />
                  <span class="text small bold">votre projet d’entreprise</span> </span> </a> </li>

            <li> <a href="#" class="btn button full secondary-lt type-formations"> <img src="images/icones/icon-on-spot-formation.png" class="icon" alt="Stage sur place" width="31" height="31" /> <span class="upper text-icon ml-large"> <span class="text">Des Professionnels aguerris pour</span> <br />
                  <span class="text small bold"> vous encadrer</span> </span> </a> </li>

            <li> <a href="#" class="btn button full secondary-lt2 type-formations"> <img src="images/icones/icon-entreprise-formation.png" class="icon" alt="" width="31" height="31" /> <span class="upper text-icon ml-xlarge"> <span class="text">Avec nos partenaires, augmentez </span> <br />
                  <span class="text small bold">vos chances de Financement</span> </span> </a> </li>
          </ul>
        </div>
      </div>
      <!-- FIN BOUTTONS VERT -->

      <!-- FORMATIONS A LA UNE -->
      <div class="row collapse row-pad">
        <div class="medium-12 columns">
          <div class="events_title"> Nos formations à la une <a class="title_home_link" href="#">Toutes nos formations</a> </div>
          <ul class="formations_home" data-equalizer data-equalizer-mq="large-only">
            <li class="formation_item">
              <div class="formation_item-body" data-equalizer-watch> <a href="#" class="formation_item_img"><img src="images/entredigiteuz.jpeg" alt="" /> </a>
                <div class="formation_home">
                  <div class="formation_home-title"> <a href="#">Bootcamp ENTRE DIGITEUZ</a> </div>
                  <div class="formation_home-chapo text-justify"> Entre Digiteuz est un programme de formation d'une journée conçu spécialement pour les femmes qui ont un business à adapter au digital. </div>
                  <a href="register.php" class="formation_link">Découvrir cette formation</a>
                </div>
              </div>
            </li>
            <li class="formation_item">
              <div class="formation_item-body" data-equalizer-watch> <a href="#" class="formation_item_img"> <img src="images/entrepreneuses.jpeg" alt="" /> </a>
                <div class="formation_home">
                  <div class="formation_home-title"> <a href="#">Bootcamp ENTRE DIGIT-PRENEUZ</a> </div>
                  <div class="formation_home-chapo text-justify"> Entre Digit Preneuz est un programme de formation d'une journée conçu spécialement pour les femmes, entrepreneures débutantes, ou aspirantes qui veulent bâtir un business numérique</a>
                  <a href="register_preneuz.php" class="formation_link">Découvrir cette formation</a>
                </div>
              </div>
            </li>
            <li class="formation_item">
              <div class="formation_item-body" data-equalizer-watch> <a href="#" class="formation_item_img"> <img src="images/entreartisans.jpg" alt="" /> </a>
                <div class="formation_home">
                  <div class="formation_home-title"> <a href="#">Bootcamp ENTRE ARTISANS</a> </div>
                  <div class="formation_home-chapo text-justify"> Entre Artisans est un programme de formation conçu pour accomapgner les gens de metier.</div>
                  <a href="register_artisans.php" class="formation_link">Découvrir cette formation</a>
                </div>
              </div>
            </li>
            <li class="formation_item">
              <div class="formation_item-body" data-equalizer-watch> <a href="#" class="formation_item_img"> <img src="images/entrepros.jpg" alt="" /> </a>
                <div class="formation_home">
                  <div class="formation_home-title"> <a href="#">Bootcamp ENTRE PROS</a> </div>
                  <div class="formation_home-chapo text-justify"> Entre PROS est un programme conçu pour les entrepreneurs qui ont besoin d’accompagnement personnalisé pour réussir à créer leur entreprise et pour permettre à cette dernière de prendre l’élan nécessaire avant de gagner en autonomie </div>
                  <a href="register_pros.php" class="formation_link">Découvrir cette formation</a>
                </div>
              </div>
            </li>
            <!--<li>-->
            <!--  <div class="bloc_financement" data-equalizer-watch>-->
            <!--    <div class="bloc_financement_title"> Prochain <br />-->
            <!--      <span class="bold">Recrutement</span> </div>-->
            <!--    <div class="bloc_financement_img"> <img src="images/img-finance.png" class="mb-large" alt="" width="235" height="100" /> </div>-->
            <!--    <div class="bloc_financement_content"> <span class="bold">Accélérez des maintenant </span> votre carrière professionnelle </div>-->
            <!--    <div class="bloc_financement_action">-->
            <!--      <a href="#" class="bloc_financement_btn">En savoir plus</a> </div>-->
            <!--  </div>-->
            <!--</li>-->
          </ul>
        </div>
      </div>
      <!-- FIN FORMATIONS A LA UNE -->

      <!-- BLOCK VIDEO -->
      <div class="bloc_video">
        <div class="bloc_video_title">Formez-vous <strong>à distance</strong> et <strong>à votre rythme</strong> ! </div>
        <div class="wrapper_bloc_video">
          <div class="video_wrapper">
            <div class="flex-video">

              <iframe width="560" height="315" src="https://www.youtube.com/embed/qC3hzkRP_ms" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
          </div>
          <div class="bloc_video_content">
            <div class="bloc_video_text">
              <p>PERFORMER est une plateforme créée spécialement par le groupe AMIRA GLOBAL TECHNOLOGES pour accompagner les porteurs de projet en les aidant à optimiser leur chance d’atteindre leur objectif entrepreneurial.</p>
<p>Cet incubateur, accélérateur est motivé par une volonté d’aider les jeunes entrepreneurs en phase création à passer le cap du démarrage dans les meilleures des conditions.
Nous mettons donc à leur disposition, des outils permettant entre autres de convaincre les investisseurs, d’apprendre à pitcher ou encore un accompagnement pour une levé de fonds. Les programmes de formations durent environ trois mois.
</p>
            </div>
            <div class="bloc_video_doc">
              <div class="accroche"><span class="accroche_yellow"></span> Vous êtes interessé  par un accompagnement ?</div>
              <div class="img_video_doc"><a href="#"><img src="images/doc_now.png" alt="" /></a></div>
              <a href="#" class="bloc_financement_btn">Inscrivez vous<br />
                dès à présent</a>
            </div>
          </div>
        </div>
      </div>
      <!-- FIN BLOCK VIDEO -->

      <!-- BLOCK ACTUALITE -->
      <div class="row blogs">
        <div class="small-12 large-5 columns">
          <div class="events_title">Agenda des Formations<a href="#">Voir tous les évènements</a></div>
          <div class="events">
            <li class="event"> <a href="#" class="event_title">Le 07-09-2020 :  Lancement Officiel du programme Entre DIGITEZ </a>
              <div class="event_resume">Entre Digiteuz est un programme de formation d'une journée conçu spécialement pour les femmes qui ont un business à adapter au digital. </div>
            </li>
            <li class="event"> <a href="#" class="event_title">Le 26-09-2020: Session 1 - Bootcamp Entre Digiteuz. </a>
              <div class="event_resume"> Programme de Pre Sélection au Programme d'encadrement et d’accompagnement de jeunes Femmes entrepreneures  </div>
            </li>
            <li class="event"> <a href="#" class="event_title">Le 03-10-2020 : Session 2 - Bootcamp Entre Digiteuz. </a>
              <div class="event_resume">Programme de Pre Sélection au Programme d'encadrement et d’accompagnement de jeunes Femmes entreprenneures </div>
            </li>
          </div>
        </div>
        <div class="small-12 large-7 columns">
          <div class="events_title">Actualités</div>
          <div class="events">
            <li class="event">
              <div class="event_img"> <a href="#"><img src="images/entredigiteuz.jpeg" class="img-thrumnail" alt="" /></a> </div>
              <div class="event_body"> <a href="#" class="event_title">07-09-2020: Lancement Officiel du programme Entre DIGITEZ</a>
                <div class="event_resume">Entre Digiteuz est un programme de formation d'une journée conçu spécialement pour les femmes qui ont un business à adapter au digital</div>
              </div>
            </li>
           
           
          </div>
        </div>
      </div>
      <!-- FIN BLOCK ACTUALITE -->


      <!-- FOOTER -->
      <?php include 'includes/footer.php'; ?>
      <!-- FIN FOOTER -->

    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
    <!-- <script type="text/javascript" src="js/modernizr.min.js"></script>
    <script type="text/javascript" src="bower_components/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript" src="bower_components/foundation/js/foundation.min.js"></script>
    <script type="text/javascript" src="bower_components/jquery.cookie/jquery.cookie.min.js"></script> -->
    <script type="text/javascript" src="js/caroufredsel.min.js"></script>
    <script type="text/javascript" src="js/app.js"></script>


</body>

</html>