$('#submitBtn')on('click', function() {
    alert(true);
})